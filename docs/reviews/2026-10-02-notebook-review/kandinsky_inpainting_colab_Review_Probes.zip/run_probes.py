"""Row 35 probes: kandinsky-inpainting-pipeline tutorials/kandinsky_inpainting_colab.ipynb at origin/main 2d19352.

CPU-only; no torch model, no weights, no generation.
Usage: python run_probes.py <worktree> <archived strict-run outputs dir> [results.json]
"""
import json
import re
import subprocess
import sys
from pathlib import Path

WT = Path(sys.argv[1])
ARCH = Path(sys.argv[2])
OUT = Path(sys.argv[3]) if len(sys.argv) > 3 else Path("results.json")
sys.path.insert(0, str(WT / "src"))
res = {}


def git(*args):
    return subprocess.run(["git", "-C", str(WT), *args], capture_output=True, text=True).stdout.strip()


nb = json.loads((WT / "tutorials/kandinsky_inpainting_colab.ipynb").read_text(encoding="utf-8"))
md = [(i, "".join(c["source"])) for i, c in enumerate(nb["cells"]) if c["cell_type"] == "markdown"]
alltext = "\n".join(s for _, s in md)

# P0 blob identity of the reviewed notebook vs the recorded runs
blob = git("rev-parse", "HEAD:tutorials/kandinsky_inpainting_colab.ipynb")
res["P0_blob"] = {
    "head": git("rev-parse", "HEAD"),
    "notebook_blob": blob,
    "matches_recorded_507e06d_blob": blob == "447723996da8868d563af5edb9587238cfdcac10",
}

# P1 CLIP 'ceiling' vs recorded generations (strict Kaggle T4 at blob 4477239)
rep = json.loads((ARCH / "kandinsky_inpainting_evaluation_report.json").read_text(encoding="utf-8"))
real = rep["references"]["original_photo_ceiling_clip"]["prompt_similarities"]
fz = rep["frozen"]["clip"]["prompt_similarities"]
ad = rep["adapted"]["clip"]["prompt_similarities"]
fill = rep["references"]["mean_fill_floor_clip"]["prompt_similarities"]
cmp_clip = rep["comparison"]["clip_prompt_similarity"]
src = "\n".join((WT / p).read_text(encoding="utf-8") for p in ["src/kandinsky_inpainting_pipeline/metrics.py", "tools/tutorial_stages.py"])
between = []
for i, s in md:
    for m in re.finditer(r"[^.\n]*(lands between the two|places both models between|places the outputs between|between a mean-fill floor of)[^.\n]*", s):
        between.append([i, m.group(0).strip()[:200]])
res["P1_ceiling"] = {
    "comparison": cmp_clip,
    "frozen_above_ceiling": cmp_clip["frozen"] > cmp_clip["original_photo_ceiling"],
    "adapted_above_ceiling": cmp_clip["adapted"] > cmp_clip["original_photo_ceiling"],
    "n": len(real),
    "per_image_frozen_gt_real": sum(f > r for f, r in zip(fz, real)),
    "per_image_adapted_gt_real": sum(a > r for a, r in zip(ad, real)),
    "per_image_fill_gt_real": sum(f > r for f, r in zip(fill, real)),
    "earlier_run_6fd3ab4_from_release_doc": {"frozen": 31.078, "adapted": 30.298, "ceiling": 30.274, "floor": 24.026},
    "ceiling_is_per_image_score_of_unmasked_photo": "real_clip = score_generations(scorer, test_images, test_prompts)" in src,
    "real_photo_baseline_present": "real_photo_baseline" in src,
    "between_claims_cell_and_text": between,
}

# P2 per-timestep loss direction vs prose
bt = rep["comparison"]["denoising_mse_test_by_timestep"]
ts = sorted(bt, key=int)
fro = [bt[t]["frozen"] for t in ts]
res["P2_timestep"] = {
    "frozen_by_t": dict(zip(ts, fro)),
    "monotonic_decreasing_with_t": all(a > b for a, b in zip(fro, fro[1:])),
    "t100_share_of_mean": round(fro[0] / len(fro) / rep["comparison"]["denoising_mse_test"]["frozen"], 3),
    "adapted_lower_at_every_t": all(bt[t]["adapted"] < bt[t]["frozen"] for t in ts),
    "section6_prose": [s[s.find("the denoising loss by timestep"):][:160] for _, s in md if "the denoising loss by timestep" in s],
    "section8_what_to_notice_mentions_timestep": any("timestep" in s for _, s in md if s.startswith("**What to notice:** read the rows")),
}

# P3 BYOD stated minimum, P4 near-duplicate and split semantics (CPU, synthetic images)
import numpy as np  # noqa: E402
from PIL import Image  # noqa: E402

from kandinsky_inpainting_pipeline import MIN_TRAIN_RECORDS  # noqa: E402
from kandinsky_inpainting_pipeline.samples import split_dataset  # noqa: E402


def rec(i, cap):
    rng = np.random.default_rng(i)
    return {"id": f"r{i}", "image": Image.fromarray(rng.integers(0, 255, (320, 320, 3), dtype=np.uint8)), "caption": cap}


def trial(recs):
    try:
        return {k: len(v) for k, v in split_dataset(recs, seed=0).items()}
    except ValueError as exc:
        return "refused: " + str(exc)


def smallest(make):
    for n in range(1, 20):
        if not isinstance(trial(make(n)), str):
            return n
    return None


res["P3_byod_minimum"] = {
    "MIN_TRAIN_RECORDS": MIN_TRAIN_RECORDS,
    "stated_minimum_4_photos_one_caption_x3": trial([rec(0, "a"), rec(1, "a"), rec(2, "a"), rec(3, "b")]),
    "4_photos_all_one_caption": trial([rec(i, "a") for i in range(4)]),
    "smallest_accepted_single_caption_n": smallest(lambda n: [rec(i, "a") for i in range(n)]),
    "smallest_accepted_two_equal_captions_n_each": smallest(lambda n: [rec(i, "a") for i in range(n)] + [rec(100 + i, "b") for i in range(n)]),
    "opening_rule": [s[s.find("you need at least"):][:150] for _, s in md if "you need at least" in s],
    "troubleshooting_rule": [s[s.find("give at least one caption three"):][:150] for _, s in md if "give at least one caption three" in s],
}
base = [rec(i, "a" if i % 2 else "b") for i in range(20)]
arr = np.array(base[0]["image"])
arr[0, 0, 0] ^= 1
near = {"id": "near-dup", "image": Image.fromarray(arr), "caption": base[0]["caption"]}
exact = {"id": "exact-dup", "image": base[0]["image"].copy(), "caption": base[0]["caption"]}
sp = split_dataset(base + [near, exact], seed=0)
where = {r["id"]: k for k, v in sp.items() for r in v}
res["P4_dedup_and_split"] = {
    "exact_pixel_duplicate_dropped": "exact-dup" not in where,
    "one_pixel_near_duplicate_kept": "near-dup" in where,
    "near_dup_split": where.get("near-dup"),
    "original_split": where.get("r0"),
    "every_split_contains_every_caption": all(len({r["caption"] for r in v}) == 2 for v in sp.values()),
}

# P5 duration claims vs release record; P6 split independence, BYOD split wording, DAT9
readme = (WT / "tutorials/README.md").read_text(encoding="utf-8")
relv = (WT / "docs/release-verification.md").read_text(encoding="utf-8")
res["P5_duration"] = {
    "notebook_says_no_timing_recorded": "No clean-runtime timing of this version has been recorded yet" in alltext,
    "tutorials_readme_runall_not_yet_recorded": "| not yet recorded |" in readme,
    "release_record_strict_kaggle_904_7_s_at_blob": "PASS** in 904.7 s" in relv and "447723996da8868d563af5edb9587238cfdcac10" in relv,
}
res["P6_split_and_dat9"] = {
    "notebook_mentions_independence": bool(re.search(r"independen", alltext, re.I)),
    "sample_one_per_observer_per_species": "one per observer per species" in alltext,
    "byod_split_by_caption_wording": [s[s.find("split by caption"):][:120] for _, s in md if "split by caption" in s],
    "dat9_pretraining_overlap_statement": "may have seen photographs like these during pretraining" in alltext,
}
print(json.dumps(res, indent=1, default=str))
OUT.write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
